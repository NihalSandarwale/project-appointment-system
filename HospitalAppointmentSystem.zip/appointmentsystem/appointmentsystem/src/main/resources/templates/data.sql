-- Insert initial data for patients
INSERT INTO patient (name) VALUES ('John Doe');
INSERT INTO patient (name) VALUES ('Jane Smith');

-- Insert initial data for doctors
INSERT INTO doctor (name) VALUES ('Dr. John Smith');
INSERT INTO doctor (name) VALUES ('Dr. Jane Doe');

-- Insert initial data for appointments
-- Ensure the patient and doctor IDs exist in the respective tables
INSERT INTO appointment (appointment_time, patient_id, doctor_id)
VALUES ('2023-03-01T10:00:00', 1, 1),
       ('2023-03-01T11:00:00', 2, 2),
       ('2023-03-02T14:00:00', 1, 2);
