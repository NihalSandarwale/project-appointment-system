package com.example.appointmentsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.appointmentsystem.model.Patient;

public interface PatientRepository extends JpaRepository<Patient, Long> {
}
